let config = {
  emailjs: {
    serviceID: "gmail",
    templateID: "template_zHrdfsdf",
    userID: "user_8g0rhdssdsd3d6Qj"
  }
};

export default config;
